// SCRIPT APLIKASI TOKO BAJU

document.addEventListener('DOMContentLoaded', function () {

    // Menampilkan tanggal hari ini
    const tanggal = document.getElementById('tanggalHariIni');

    if (tanggal) {
        const hariIni = new Date();

        tanggal.textContent = hariIni.toLocaleDateString(
            'id-ID',
            {
                day: 'numeric',
                month: 'long',
                year: 'numeric'
            }
        );
    }

    // Konfirmasi tombol hapus
    const tombolHapus = document.querySelectorAll('.btn-hapus');

    tombolHapus.forEach(function (tombol) {

        tombol.addEventListener('click', function (event) {

            const yakin = confirm(
                'Apakah kamu yakin ingin menghapus data ini?'
            );

            if (!yakin) {
                event.preventDefault();
            }

        });

    });

    // Pencarian tabel
    const pencarian = document.getElementById('searchInput');

    if (pencarian) {

        pencarian.addEventListener('keyup', function () {

            const kataKunci = pencarian.value.toLowerCase();

            const baris = document.querySelectorAll('tbody tr');

            baris.forEach(function (row) {

                const isi = row.textContent.toLowerCase();

                row.style.display = isi.includes(kataKunci)
                    ? ''
                    : 'none';

            });

        });

    }

});